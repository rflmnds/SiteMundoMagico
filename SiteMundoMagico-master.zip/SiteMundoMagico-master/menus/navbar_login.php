    <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
        <div class="container">
            <a class="navbar-brand" href="index.php#page-top"><img height="70px" src="./img/logoMenu.png"></a>
            <a class="btn btn-primary text-uppercase font-weight-bold text-white rounded" href="index.php#page-top">Voltar</a>
        </div>
    </nav>